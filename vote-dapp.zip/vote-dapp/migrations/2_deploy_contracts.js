//var VoteContract = artifacts.require("VoteContract");
//var Ballot = artifacts.require("Ballot");
var myBallot = artifacts.require("myBallot");
module.exports = function(deployer) {
  //deployer.deploy(VoteContract);
  //deployer.deploy(Ballot);
  deployer.deploy(myBallot);
};


